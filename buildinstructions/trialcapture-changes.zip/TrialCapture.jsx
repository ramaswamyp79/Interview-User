import React, { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { useNavigate } from 'react-router-dom';
import './TrialCapture.css';

// Use Vite's import.meta.env (process is not available in the browser)
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:3000';

export default function TrialCapture() {
  const videoRef = useRef(null);
  const transcriptRef = useRef(null);
  const answerContainerRef = useRef(null);
  const fileInputRef = useRef(null);
  const questionRef = useRef(null);

  const socketRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const localMediaStreamRef = useRef(null);
  const silenceIntervalRef = useRef(null);
  const restartIntervalRef = useRef(null);
  const lastSpeechTimeRef = useRef(Date.now());

  const [status, setStatus] = useState('disconnected'); // disconnected | connecting | connected
  const [isRecording, setIsRecording] = useState(false);
  const [email, setEmail] = useState(null);
  const navigate = useNavigate();

  function updateStatus(newStatus) {
    setStatus(newStatus);
  }

  async function startTranscriptionProcess() {
    updateStatus('connecting');

    try {
      if (!localMediaStreamRef.current) {
        if (!email) {
          const value = window.prompt('Please Confirm Your Email Address');
          setEmail(value || null);
        }
        localMediaStreamRef.current = await navigator.mediaDevices.getDisplayMedia({
          video: { width: { ideal: 640 }, height: { ideal: 360 } },
          audio: true,
        });
        if (videoRef.current) videoRef.current.srcObject = localMediaStreamRef.current;
      }

      const audioTracks = localMediaStreamRef.current.getAudioTracks();
      if (audioTracks.length === 0) {
        // try to re-request
        localMediaStreamRef.current = await navigator.mediaDevices.getDisplayMedia({
          video: { width: { ideal: 640 }, height: { ideal: 360 } },
          audio: true,
        });
        if (videoRef.current) videoRef.current.srcObject = localMediaStreamRef.current;
      }

      const audioOnlyStream = new MediaStream(localMediaStreamRef.current.getAudioTracks());

      // disconnect old socket
      if (socketRef.current && socketRef.current.connected) {
        socketRef.current.disconnect();
      }

      socketRef.current = io(SOCKET_URL);

      socketRef.current.on('connect', () => {
        updateStatus('connected');

        try {
          mediaRecorderRef.current = new MediaRecorder(audioOnlyStream, {
            mimeType: 'audio/webm;codecs=opus',
          });

          mediaRecorderRef.current.ondataavailable = async (event) => {
            if (event.data && event.data.size > 0 && socketRef.current?.connected) {
              const buffer = await event.data.arrayBuffer();
              socketRef.current.emit('audioChunk', buffer);
              lastSpeechTimeRef.current = Date.now();
              updateStatus('connected');
            }
          };

          mediaRecorderRef.current.start(250);
          setIsRecording(true);

          if (transcriptRef.current) transcriptRef.current.textContent = '🎙️ Listening...\n';

          socketRef.current.emit('startTranscription', {
            audioEncoding: 'WEBM_OPUS',
            audioSampleRate: 48000,
            languageCode: 'en-US',
            email,
          });

          clearInterval(silenceIntervalRef.current);
          silenceIntervalRef.current = setInterval(() => {
            const timeSinceLast = Date.now() - lastSpeechTimeRef.current;
            if (timeSinceLast >= 5 * 60 * 1000 && socketRef.current?.connected) {
              console.log('Silence exceeded 5 minutes, stopping capture due to inactivity.');
              updateStatus('idle');
              stopConnection();
            } else if (socketRef.current?.connected) {
              updateStatus('connected');
            }
          }, 60 * 1000);
        } catch (err) {
          console.error('MediaRecorder creation failed:', err);
        }
      });

      socketRef.current.on('transcriptionResult', (data) => {
        if (transcriptRef.current) transcriptRef.current.textContent = data.transcript + '\n';
        lastSpeechTimeRef.current = Date.now();
        updateStatus('connected');
      });

      socketRef.current.on('shortanswer', (data) => {
        if (answerContainerRef.current) answerContainerRef.current.innerHTML += data;
        updateStatus('connected');
      });

      socketRef.current.on('question', (data) => {
        if (answerContainerRef.current) answerContainerRef.current.innerHTML += data;
        updateStatus('connected');
      });

      socketRef.current.on('qindex', (data) => {
        // handled by server-rendered HTML inside answer container
        updateStatus('connected');
      });

      socketRef.current.on('longanswer', (data) => {
        if (answerContainerRef.current) answerContainerRef.current.innerHTML += data;
        updateStatus('connected');
      });

      socketRef.current.on('transcriptionError', (error) => {
        console.error('Transcription error from server:', error);
        if (transcriptRef.current) transcriptRef.current.textContent += `\n⚠️ Error with Transcription: ${error}\n`;
        updateStatus('disconnected');
        setIsRecording(false);
      });

      socketRef.current.on('disconnect', () => {
        clearInterval(silenceIntervalRef.current);
        if (transcriptRef.current) transcriptRef.current.textContent += '\n🛑 Disconnected from server.\n';
        setIsRecording(false);
        updateStatus('disconnected');
      });

      socketRef.current.on('connect_error', (err) => {
        console.error('Socket.IO connect_error:', err);
        if (transcriptRef.current) transcriptRef.current.textContent += `\n⚠️ Connection Error: ${err}\n`;
        setIsRecording(false);
        updateStatus('disconnected');
      });
    } catch (err) {
      console.error('Error accessing media devices:', err);
      if (transcriptRef.current) transcriptRef.current.textContent = `⚠️ Error accessing media: ${err.message}\n`;
      setIsRecording(false);
      updateStatus('disconnected');
      stopLocalMedia();
    }
  }

  function restartTranscription() {
    console.log('Restarting transcription...');
    try {
      if (mediaRecorderRef.current?.state === 'recording') mediaRecorderRef.current.stop();
      if (socketRef.current?.connected) socketRef.current.disconnect();
      clearInterval(silenceIntervalRef.current);

      setTimeout(() => {
        startTranscriptionProcess();
      }, 500);
    } catch (err) {
      console.error(err);
    }
  }

  function stopConnection(shouldStopMedia = false) {
    try {
      if (mediaRecorderRef.current?.state === 'recording') mediaRecorderRef.current.stop();
      if (socketRef.current?.connected) socketRef.current.disconnect();
      clearInterval(silenceIntervalRef.current);
      clearInterval(restartIntervalRef.current);
      restartIntervalRef.current = null;
      setIsRecording(false);
      updateStatus('disconnected');

      if (shouldStopMedia) stopLocalMedia();
    } catch (err) {
      console.error('Error stopping connection:', err);
    }
  }

  function stopLocalMedia() {
    if (localMediaStreamRef.current) {
      localMediaStreamRef.current.getTracks().forEach((t) => t.stop());
      localMediaStreamRef.current = null;
    }
    if (videoRef.current?.srcObject) {
      const tracks = videoRef.current.srcObject.getTracks();
      tracks.forEach((t) => t.stop());
      videoRef.current.srcObject = null;
    }
  }

  async function handleStart() {
    if (restartIntervalRef.current === null) {
      await startTranscriptionProcess();
      restartIntervalRef.current = setInterval(restartTranscription, 2 * 60 * 1000);
    }
  }

  function handleStop() {
    stopConnection(true);
  }

  async function handleUpload() {
    try {
      if (!socketRef.current) {
        socketRef.current = io(SOCKET_URL);
      }
      const file = fileInputRef.current?.files?.[0];
      if (!file) return alert('No file selected');
      const reader = new FileReader();
      reader.onload = () => {
        const arrayBuffer = reader.result;
        socketRef.current.emit('uploadFile', {
          fileName: file.name,
          fileType: file.type,
          fileBuffer: arrayBuffer,
        });
      };
      reader.readAsArrayBuffer(file);
    } catch (err) {
      updateStatus('error');
    }
  }

  function handleClear() {
    try {
      if (answerContainerRef.current) answerContainerRef.current.innerHTML = '';
    } catch (err) {
      updateStatus('error');
    }
  }

  function handleSendQuestion() {
    try {
      const question = questionRef.current?.value?.trim();
      if (question && socketRef.current?.connected) {
        socketRef.current.emit('sendPrompt', { prompt: question });
      } else {
        console.error('Socket is not connected or question is empty.');
      }
    } catch (err) {
      updateStatus('error');
    }
  }

  function handleBack() {
    try {
      // Confirm with the user before terminating the session
      const confirmLeave = window.confirm("Your Interview Session will be terminated, You May need to connect Again.. Are you Ok..");
      if (!confirmLeave) return;

      // Ensure we stop active recording/socket and release media before navigating back
      stopConnection(true);
      navigate('/home');
    } catch (err) {
      console.error('Error during navigation back:', err);
      navigate('/home');
    }
  }

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      try {
        if (mediaRecorderRef.current?.state === 'recording') mediaRecorderRef.current.stop();
        if (socketRef.current?.connected) socketRef.current.disconnect();
        clearInterval(silenceIntervalRef.current);
        clearInterval(restartIntervalRef.current);
        stopLocalMedia();
      } catch (err) {
        console.error('Cleanup error:', err);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div id="trial-capture-root" className="transparent-border p-4 rounded-lg">
      <div id="top-row" className="transparent-border flex justify-between items-center px-2 py-1">
        <div id="logo-container" className="flex items-center">
          <img src="/logo.png" alt="Product Logo" style={{ maxHeight: '80%' }} />
        </div>

        <div id="file-actions-container" className="flex items-center">
          <button onClick={handleBack} className="btn btn-secondary mr-2">← Back to Home</button>
          <input ref={fileInputRef} type="file" className="form-control-file mr-2" id="fileInput" />
          <button onClick={handleUpload} id="uploadButton" className="btn btn-primary mr-2">Upload File</button>
          <button onClick={handleClear} id="clearButton" className="btn btn-warning">Clear Answer</button>
        </div>
      </div>

      <div id="middle-row" className="flex mt-3">
        <div id="portion-a" className="w-1/2 pr-2">
          <video ref={videoRef} id="videoDisplay" autoPlay muted className="transparent-border w-full" />

          <div id="chatControls" className="transparent-border mt-2 flex items-center gap-2">
            <span id="statusIndicator" className={`badge ${status}`} title={status}></span>
            <button id="start" onClick={handleStart} className="btn btn-primary btn-sm" disabled={isRecording}>Start Capture &amp; Transcription</button>
            <button id="stop" onClick={handleStop} className="btn btn-danger btn-sm" disabled={!isRecording}>Stop</button>
            <button onClick={() => document.documentElement.requestFullscreen?.()} className="btn btn-sm">Fullscreen</button>
          </div>

          <textarea ref={transcriptRef} id="transcript" readOnly placeholder="Transcription will appear here..." className="transparent-border form-control mt-2" style={{ height: '7cm' }} />

          <div id="question-container" className="transparent-border mt-2 flex items-center">
            <textarea ref={questionRef} id="questionBox" placeholder="Enter your question..." className="form-control mr-2" style={{ height: '2cm' }} />
            <button id="sendQuestion" onClick={handleSendQuestion} className="btn btn-info btn-sm">Query</button>
          </div>
        </div>

        <div id="portion-b" className="w-1/2 pl-2">
          <div id="answer-container" ref={answerContainerRef} className="transparent-border p-2 overflow-auto" style={{ height: '100%' }} />
        </div>
      </div>
    </div>
  );
}
